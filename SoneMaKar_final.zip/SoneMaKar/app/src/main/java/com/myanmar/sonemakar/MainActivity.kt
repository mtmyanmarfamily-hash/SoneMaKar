package com.myanmar.sonemakar

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var etCarNumber: EditText
    private lateinit var btnAddCar: Button
    private lateinit var btnTestNotification: Button
    private lateinit var btnVoice: Button
    private lateinit var btnStopVoice: Button
    private lateinit var tvStatus: TextView
    private lateinit var tvTodayResult: TextView
    private lateinit var cardResult: CardView
    private lateinit var llCarList: LinearLayout
    private lateinit var tvCarType: TextView
    private lateinit var tvDayType: TextView
    private lateinit var tvCanGo: TextView

    private var voiceService: VoiceAnnouncementService? = null
    private val refreshHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private var currentDay = java.util.Calendar.getInstance().get(java.util.Calendar.DAY_OF_MONTH)

    private val carPrefsKey = "car_numbers"
    private val sharedPrefsName = "SoneMaKarPrefs"
    private val notificationTimeHourKey = "notif_hour"
    private val notificationTimeMinKey = "notif_min"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        createNotificationChannel()
        requestNotificationPermission()
        voiceService = VoiceAnnouncementService(this)

        etCarNumber    = findViewById(R.id.etCarNumber)
        btnAddCar      = findViewById(R.id.btnAddCar)
        btnTestNotification = findViewById(R.id.btnTestNotification)
        btnVoice       = findViewById(R.id.btnVoice)
        btnStopVoice   = findViewById(R.id.btnStopVoice)
        tvStatus       = findViewById(R.id.tvStatus)
        tvTodayResult  = findViewById(R.id.tvTodayResult)
        cardResult     = findViewById(R.id.cardResult)
        llCarList      = findViewById(R.id.llCarList)
        tvCarType      = findViewById(R.id.tvCarType)
        tvDayType      = findViewById(R.id.tvDayType)
        tvCanGo        = findViewById(R.id.tvCanGo)

        etCarNumber.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                val input = s.toString().trim()
                if (input.isNotEmpty()) showPreview(input) else cardResult.visibility = View.GONE
            }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        btnAddCar.setOnClickListener {
            val carNumber = etCarNumber.text.toString().trim().uppercase()
            if (carNumber.isEmpty()) { showToast("ကားနံပါတ် ထည့်ပါ"); return@setOnClickListener }
            if (!isValidCarNumber(carNumber)) { showToast("ကားနံပါတ် မှားနေသည် (ဥပမာ: 1H/7123)"); return@setOnClickListener }
            addCarNumber(carNumber)
            etCarNumber.text.clear()
            cardResult.visibility = View.GONE
        }

        btnTestNotification.setOnClickListener {
            val cars = getSavedCars()
            if (cars.isEmpty()) showToast("ကားနံပါတ် အနည်းဆုံး တစ်စီး ထည့်ပါ")
            else NotificationHelper.sendDailyNotification(this, cars)
        }

        btnVoice.setOnClickListener {
            val cars = getSavedCars()
            if (cars.isEmpty()) {
                showToast("ကားနံပါတ် အနည်းဆုံး တစ်စီး ထည့်ပါ")
                return@setOnClickListener
            }
            btnVoice.text = "🔊 ဖတ်နေသည်..."
            btnVoice.isEnabled = false
            btnStopVoice.visibility = View.VISIBLE
            voiceService?.announceCarStatus(cars) {
                runOnUiThread {
                    btnVoice.text = "🔊 အသံဖြင့် ကြားချင်သည်"
                    btnVoice.isEnabled = true
                    btnStopVoice.visibility = View.GONE
                }
            }
        }

        btnStopVoice.setOnClickListener {
            voiceService?.stop()
            btnVoice.text = "🔊 အသံဖြင့် ကြားချင်သည်"
            btnVoice.isEnabled = true
            btnStopVoice.visibility = View.GONE
        }

        scheduleDailyNotification()
        refreshCarList()
        startMidnightChecker()
    }

    private fun showPreview(input: String) {
        val upper = input.uppercase()
        if (!isValidCarNumber(upper)) { cardResult.visibility = View.GONE; return }
        val startDigit = extractStartDigit(upper)
        val isOdd = startDigit % 2 != 0
        val todayIsOdd = isTodayOdd()
        cardResult.visibility = View.VISIBLE
        tvCarType.text = if (isOdd) "မ ကား" else "စုံ ကား"
        tvDayType.text = if (todayIsOdd) "ဒီနေ့ - မ နေ့" else "ဒီနေ့ - စုံ နေ့"
        val canGo = (isOdd && todayIsOdd) || (!isOdd && !todayIsOdd)
        tvCanGo.text = if (canGo) "✅ ဒီနေ့ ထွက်လို့ ရသည်" else "❌ ဒီနေ့ ထွက်ခွင့် မရ"
        cardResult.setCardBackgroundColor(if (canGo) getColor(R.color.canGoGreen) else getColor(R.color.cannotGoRed))
    }

    private fun isValidCarNumber(number: String): Boolean = Regex("^\\d+[A-Z]+/\\d+$").matches(number)

    private fun extractStartDigit(carNumber: String): Int {
        return Regex("^(\\d+)").find(carNumber)?.value?.toIntOrNull() ?: 0
    }

    private fun isTodayOdd(): Boolean = Calendar.getInstance().get(Calendar.DAY_OF_MONTH) % 2 != 0

    private fun addCarNumber(carNumber: String) {
        val cars = getSavedCars().toMutableSet()
        if (cars.contains(carNumber)) { showToast("ဒီကားနံပါတ် ရှိပြီးသား"); return }
        cars.add(carNumber); saveCars(cars); refreshCarList()
        showToast("$carNumber ထည့်သွင်းပြီး")
    }

    private fun getSavedCars(): Set<String> =
        getSharedPreferences(sharedPrefsName, Context.MODE_PRIVATE).getStringSet(carPrefsKey, emptySet()) ?: emptySet()

    private fun saveCars(cars: Set<String>) =
        getSharedPreferences(sharedPrefsName, Context.MODE_PRIVATE).edit().putStringSet(carPrefsKey, cars).apply()

    private fun removeCar(carNumber: String) {
        val cars = getSavedCars().toMutableSet()
        cars.remove(carNumber); saveCars(cars); refreshCarList()
        showToast("$carNumber ဖျက်လိုက်သည်")
    }

    private fun refreshCarList() {
        llCarList.removeAllViews()
        val cars = getSavedCars().sorted()
        val todayIsOdd = isTodayOdd()
        if (cars.isEmpty()) {
            val tv = TextView(this).apply {
                text = "ကားနံပါတ် မရှိသေး"; setPadding(16,24,16,24)
                setTextColor(getColor(R.color.textSecondary)); textSize = 14f
            }
            llCarList.addView(tv); return
        }
        for (car in cars) {
            val isOdd = extractStartDigit(car) % 2 != 0
            val canGo = (isOdd && todayIsOdd) || (!isOdd && !todayIsOdd)
            val itemView = layoutInflater.inflate(R.layout.item_car, llCarList, false)
            itemView.findViewById<TextView>(R.id.tvCarNumber).text = car
            itemView.findViewById<TextView>(R.id.tvCarTypeItem).text = if (isOdd) "မ ကား" else "စုံ ကား"
            val tvResult = itemView.findViewById<TextView>(R.id.tvResult)
            tvResult.text = if (canGo) "✅ ထွက်လို့ရ" else "❌ မထွက်ရ"
            tvResult.setTextColor(if (canGo) getColor(R.color.canGoGreen) else getColor(R.color.cannotGoRed))
            itemView.findViewById<CardView>(R.id.cardItem).setCardBackgroundColor(
                if (canGo) getColor(R.color.cardGreen) else getColor(R.color.cardRed))
            itemView.findViewById<ImageButton>(R.id.btnDelete).setOnClickListener { removeCar(car) }
            llCarList.addView(itemView)
        }
    }

    private fun scheduleDailyNotification() {
        val prefs = getSharedPreferences(sharedPrefsName, Context.MODE_PRIVATE)
        val hour = prefs.getInt(notificationTimeHourKey, 7)
        val min = prefs.getInt(notificationTimeMinKey, 0)
        val alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (!alarmManager.canScheduleExactAlarms()) {
                startActivity(Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM))
                return
            }
        }
        val intent = Intent(this, NotificationReceiver::class.java)
        val pi = PendingIntent.getBroadcast(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, min)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DATE, 1)
        }
        alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(NotificationHelper.CHANNEL_ID, "စုံမကား သတိပေးချက်", NotificationManager.IMPORTANCE_HIGH)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 101)
        }
    }

    private fun showToast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    // Check every 30 seconds if date has changed — auto refresh at midnight
    private fun startMidnightChecker() {
        refreshHandler.postDelayed(object : Runnable {
            override fun run() {
                val today = java.util.Calendar.getInstance().get(java.util.Calendar.DAY_OF_MONTH)
                if (today != currentDay) {
                    currentDay = today
                    refreshCarList() // Date changed! Update card colors
                }
                refreshHandler.postDelayed(this, 30_000) // check every 30 sec
            }
        }, 30_000)
    }

    override fun onResume() {
        super.onResume()
        refreshCarList() // Refresh colors when app comes to foreground or date changes
        refreshCarList() // Refresh card colors when app comes to foreground
    }

    override fun onDestroy() { voiceService?.shutdown(); refreshHandler.removeCallbacksAndMessages(null); super.onDestroy() }
}

// Extension to auto-refresh UI every time app comes to foreground
