package com.myanmar.sonemakar

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import java.util.Calendar

object NotificationHelper {

    const val CHANNEL_ID = "sone_ma_kar_channel"

    fun sendDailyNotification(context: Context, cars: Set<String>) {
        val todayIsOdd = isTodayOdd()
        val dayLabel = if (todayIsOdd) "မ နေ့" else "စုံ နေ့"
        val date = Calendar.getInstance().let {
            "${it.get(Calendar.DAY_OF_MONTH)}/${it.get(Calendar.MONTH) + 1}/${it.get(Calendar.YEAR)}"
        }

        val canGoList = mutableListOf<String>()
        val cannotGoList = mutableListOf<String>()

        for (car in cars) {
            val startDigit = extractStartDigit(car)
            val isOdd = startDigit % 2 != 0
            val canGo = (isOdd && todayIsOdd) || (!isOdd && !todayIsOdd)
            if (canGo) canGoList.add(car) else cannotGoList.add(car)
        }

        val title = "🚗 စုံမကား သတိပေးချက် — $date ($dayLabel)"
        val body = buildString {
            if (canGoList.isNotEmpty()) {
                append("✅ ထွက်လို့ရ: ${canGoList.joinToString(", ")}\n")
            }
            if (cannotGoList.isNotEmpty()) {
                append("❌ မထွက်ရ: ${cannotGoList.joinToString(", ")}")
            }
        }

        val intent = Intent(context, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            context, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_car)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(1001, notification)
    }

    private fun extractStartDigit(carNumber: String): Int {
        val match = Regex("^(\\d+)").find(carNumber)
        return match?.value?.toIntOrNull() ?: 0
    }

    private fun isTodayOdd(): Boolean {
        val day = Calendar.getInstance().get(Calendar.DAY_OF_MONTH)
        return day % 2 != 0
    }
}
