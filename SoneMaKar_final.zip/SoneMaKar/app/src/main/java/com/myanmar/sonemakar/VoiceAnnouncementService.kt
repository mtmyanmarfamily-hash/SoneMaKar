package com.myanmar.sonemakar

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import java.net.URLEncoder
import java.util.Calendar

class VoiceAnnouncementService(private val context: Context) {

    private val handler = Handler(Looper.getMainLooper())
    private var currentPlayer: MediaPlayer? = null
    private var stopped = false

    private val numberWords = mapOf(
        "0" to "zero", "1" to "one", "2" to "two", "3" to "three",
        "4" to "four", "5" to "five", "6" to "six", "7" to "seven",
        "8" to "eight", "9" to "nine", "10" to "ten", "11" to "eleven",
        "12" to "twelve"
    )

    fun announceCarStatus(cars: Set<String>, onDone: () -> Unit = {}) {
        stopped = false
        val todayIsOdd = isTodayOdd()
        val dayWord = if (todayIsOdd) "မ နေ့" else "စုံ နေ့"

        val canGoList = mutableListOf<String>()
        val cannotGoList = mutableListOf<String>()

        for (car in cars) {
            val isOdd = extractStartDigit(car) % 2 != 0
            val canGo = (isOdd && todayIsOdd) || (!isOdd && !todayIsOdd)
            if (canGo) canGoList.add(car) else cannotGoList.add(car)
        }

        val queue = mutableListOf<Pair<String, String>>()
        queue.add(Pair("ယနေ့သည် ${dayWord} ဖြစ်သည်", "my"))
        for (car in cannotGoList) {
            queue.add(Pair(speakableCarNumber(car.substringBefore("/")), "en"))
            queue.add(Pair("ကားကို အသုံးမပြုနိုင်ပါ", "my"))
        }
        for (car in canGoList) {
            queue.add(Pair(speakableCarNumber(car.substringBefore("/")), "en"))
            queue.add(Pair("ကားကို အသုံးပြုနိုင်ပါသည်", "my"))
        }

        playQueue(queue, 0, onDone)
    }

    private fun playQueue(queue: List<Pair<String, String>>, index: Int, onDone: () -> Unit) {
        if (stopped || index >= queue.size) {
            onDone()
            return
        }

        val (text, lang) = queue[index]
        val encoded = URLEncoder.encode(text, "UTF-8")
        val url = "https://translate.google.com/translate_tts?ie=UTF-8&q=$encoded&tl=$lang&client=tw-ob"

        try {
            currentPlayer?.release()
            currentPlayer = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build()
                )
                setDataSource(url)
                setOnPreparedListener {
                    if (!stopped) start()
                    else {
                        release()
                        onDone()
                    }
                }
                setOnCompletionListener {
                    release()
                    currentPlayer = null
                    // Small pause between sentences only
                    val delay = if (lang == "en") 0L else 100L
                    handler.postDelayed({
                        playQueue(queue, index + 1, onDone)
                    }, delay)
                }
                setOnErrorListener { _, _, _ ->
                    release()
                    currentPlayer = null
                    playQueue(queue, index + 1, onDone)
                    true
                }
                prepareAsync()
            }
        } catch (e: Exception) {
            playQueue(queue, index + 1, onDone)
        }
    }

    private fun speakableCarNumber(prefix: String): String {
        val digits = prefix.filter { it.isDigit() }
        val letters = prefix.filter { it.isLetter() }
        val numberWord = numberWords[digits] ?: digits
        val letterSpelled = letters.map { it.toString() }.joinToString(" ")
        return "$numberWord $letterSpelled"
    }

    fun stop() {
        stopped = true
        handler.removeCallbacksAndMessages(null)
        currentPlayer?.release()
        currentPlayer = null
    }

    fun shutdown() { stop() }

    private fun extractStartDigit(carNumber: String) =
        Regex("^(\\d+)").find(carNumber)?.value?.toIntOrNull() ?: 0

    private fun isTodayOdd() =
        Calendar.getInstance().get(Calendar.DAY_OF_MONTH) % 2 != 0
}
