package com.myanmar.sonemakar

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import java.net.URLEncoder
import java.util.Calendar
import java.util.Locale

class VoiceAnnouncementService(private val context: Context) {

    private var mediaPlayer: MediaPlayer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val handler = Handler(Looper.getMainLooper())
    private val queue = mutableListOf<String>()

    private val numberWords = mapOf(
        "0" to "zero", "1" to "one", "2" to "two", "3" to "three",
        "4" to "four", "5" to "five", "6" to "six", "7" to "seven",
        "8" to "eight", "9" to "nine", "10" to "ten", "11" to "eleven",
        "12" to "twelve"
    )

    init {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) ttsReady = true
        }
    }

    fun announceCarStatus(cars: Set<String>, onDone: () -> Unit = {}) {
        val todayIsOdd = isTodayOdd()
        val dayWord = if (todayIsOdd) "မနေ့" else "စုံနေ့"

        val canGoList = mutableListOf<String>()
        val cannotGoList = mutableListOf<String>()

        for (car in cars) {
            val isOdd = extractStartDigit(car) % 2 != 0
            val canGo = (isOdd && todayIsOdd) || (!isOdd && !todayIsOdd)
            if (canGo) canGoList.add(car) else cannotGoList.add(car)
        }

        // Build ONE full announcement string — single network request, zero gap
        val sb = StringBuilder()
        sb.append("ယနေ့သည် ${dayWord} ဖြစ်သည်။ ")

        for (car in cannotGoList) {
            val num = speakableCarNumber(car.substringBefore("/"))
            sb.append("$num car cannot be used. ")
        }
        for (car in canGoList) {
            val num = speakableCarNumber(car.substringBefore("/"))
            sb.append("$num car can be used. ")
        }

        val fullText = sb.toString().trim()
        playSingle(fullText, onDone)
    }

    private fun speakableCarNumber(prefix: String): String {
        val digits = prefix.filter { it.isDigit() }
        val letters = prefix.filter { it.isLetter() }
        val numberWord = numberWords[digits] ?: digits
        val letterSpelled = letters.map { it.toString() }.joinToString(" ")
        return "$numberWord $letterSpelled"
    }

    private fun playSingle(text: String, onComplete: () -> Unit) {
        try {
            val encoded = URLEncoder.encode(text, "UTF-8")
            // Use "en" so Google TTS handles mixed Myanmar+English smoothly
            val url = "https://translate.google.com/translate_tts?ie=UTF-8&q=$encoded&tl=my&client=tw-ob"

            mediaPlayer?.release()
            mediaPlayer = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build()
                )
                setDataSource(url)
                setOnPreparedListener { start() }
                setOnCompletionListener { onComplete() }
                setOnErrorListener { _, _, _ ->
                    fallbackTTS(text, onComplete)
                    true
                }
                prepareAsync()
            }
        } catch (e: Exception) {
            fallbackTTS(text, onComplete)
        }
    }

    private fun fallbackTTS(text: String, onComplete: () -> Unit) {
        if (ttsReady) {
            tts?.setLanguage(Locale.ENGLISH)
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "utt_${System.currentTimeMillis()}")
            handler.postDelayed({ onComplete() }, (text.length * 80L).coerceAtLeast(2000L))
        } else {
            onComplete()
        }
    }

    fun stop() {
        mediaPlayer?.stop()
        mediaPlayer?.release()
        mediaPlayer = null
        tts?.stop()
        queue.clear()
        handler.removeCallbacksAndMessages(null)
    }

    fun shutdown() { stop(); tts?.shutdown() }

    private fun extractStartDigit(carNumber: String) =
        Regex("^(\\d+)").find(carNumber)?.value?.toIntOrNull() ?: 0

    private fun isTodayOdd() =
        Calendar.getInstance().get(Calendar.DAY_OF_MONTH) % 2 != 0
}
