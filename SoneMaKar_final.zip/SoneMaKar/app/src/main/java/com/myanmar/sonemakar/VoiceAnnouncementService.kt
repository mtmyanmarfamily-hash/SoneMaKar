package com.myanmar.sonemakar

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import java.net.URLEncoder
import java.util.Calendar
import java.util.Locale

class VoiceAnnouncementService(private val context: Context) {

    private var mediaPlayer: MediaPlayer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val handler = Handler(Looper.getMainLooper())
    private val queue = mutableListOf<Pair<String, String>>() // text + lang

    init {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = true
            }
        }
    }

    // Number words in Myanmar
    private val numberWords = mapOf(
        "0" to "zero", "1" to "one", "2" to "two", "3" to "three",
        "4" to "four", "5" to "five", "6" to "six", "7" to "seven",
        "8" to "eight", "9" to "nine", "10" to "ten", "11" to "eleven",
        "12" to "twelve"
    )

    fun announceCarStatus(cars: Set<String>, onDone: () -> Unit = {}) {
        val todayIsOdd = isTodayOdd()
        val dayWord = if (todayIsOdd) "မနေ့" else "စုံနေ့"

        val canGoList = mutableListOf<String>()
        val cannotGoList = mutableListOf<String>()

        for (car in cars) {
            val startDigit = extractStartDigit(car)
            val isOdd = startDigit % 2 != 0
            val canGo = (isOdd && todayIsOdd) || (!isOdd && !todayIsOdd)
            if (canGo) canGoList.add(car) else cannotGoList.add(car)
        }

        // Build queue: each item is (text, language)
        queue.clear()

        // Myanmar sentence
        queue.add(Pair("ယနေ့သည် ${dayWord} ဖြစ်သည်", "my"))

        for (car in cannotGoList) {
            val prefix = car.substringBefore("/")
            // Speak car number in English, rest in Myanmar
            queue.add(Pair(speakableCarNumber(prefix), "en"))
            queue.add(Pair("ကားကို အသုံးမပြုနိုင်ပါ", "my"))
        }

        for (car in canGoList) {
            val prefix = car.substringBefore("/")
            queue.add(Pair(speakableCarNumber(prefix), "en"))
            queue.add(Pair("ကားကို အသုံးပြုနိုင်ပါသည်", "my"))
        }

        playQueue(0, onDone)
    }

    // "7H" → "seven H", "2F" → "two F", "1HA" → "one H A"
    private fun speakableCarNumber(prefix: String): String {
        val digits = prefix.filter { it.isDigit() }
        val letters = prefix.filter { it.isLetter() }
        val numberWord = numberWords[digits] ?: digits
        val letterSpelled = letters.map { it.toString() }.joinToString(" ")
        return "$numberWord $letterSpelled"
    }

    private fun playQueue(index: Int, onDone: () -> Unit) {
        if (index >= queue.size) {
            onDone()
            return
        }

        val (text, lang) = queue[index]

        playTTS(text, lang) {
            handler.postDelayed({
                playQueue(index + 1, onDone)
            }, 200)
        }
    }

    private fun playTTS(text: String, lang: String, onComplete: () -> Unit) {
        try {
            val encoded = URLEncoder.encode(text, "UTF-8")
            val url = "https://translate.google.com/translate_tts?ie=UTF-8&q=$encoded&tl=$lang&client=tw-ob"

            mediaPlayer?.release()
            mediaPlayer = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build()
                )
                setDataSource(url)
                setOnPreparedListener { start() }
                setOnCompletionListener { onComplete() }
                setOnErrorListener { _, _, _ ->
                    fallbackTTS(text, lang, onComplete)
                    true
                }
                prepareAsync()
            }
        } catch (e: Exception) {
            fallbackTTS(text, lang, onComplete)
        }
    }

    private fun fallbackTTS(text: String, lang: String, onComplete: () -> Unit) {
        if (ttsReady) {
            val locale = if (lang == "en") Locale.ENGLISH else Locale("my", "MM")
            tts?.setLanguage(locale)
            val id = "utt_${System.currentTimeMillis()}"
            tts?.speak(text, TextToSpeech.QUEUE_ADD, null, id)
            handler.postDelayed({ onComplete() }, (text.length * 100L).coerceAtLeast(1200L))
        } else {
            onComplete()
        }
    }

    fun stop() {
        mediaPlayer?.stop()
        mediaPlayer?.release()
        mediaPlayer = null
        tts?.stop()
        queue.clear()
        handler.removeCallbacksAndMessages(null)
    }

    fun shutdown() {
        stop()
        tts?.shutdown()
    }

    private fun extractStartDigit(carNumber: String): Int {
        return Regex("^(\\d+)").find(carNumber)?.value?.toIntOrNull() ?: 0
    }

    private fun isTodayOdd(): Boolean {
        return Calendar.getInstance().get(Calendar.DAY_OF_MONTH) % 2 != 0
    }
}
