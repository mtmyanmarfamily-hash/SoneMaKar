package com.myanmar.sonemakar

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import java.net.URLEncoder
import java.util.Calendar
import java.util.Locale

class VoiceAnnouncementService(private val context: Context) {

    private var mediaPlayer: MediaPlayer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val handler = Handler(Looper.getMainLooper())

    // Each item: Pair(text, lang)
    private val queue = mutableListOf<Pair<String, String>>()
    // Pre-fetched next player
    private var nextPlayer: MediaPlayer? = null

    private val numberWords = mapOf(
        "0" to "zero", "1" to "one", "2" to "two", "3" to "three",
        "4" to "four", "5" to "five", "6" to "six", "7" to "seven",
        "8" to "eight", "9" to "nine", "10" to "ten", "11" to "eleven",
        "12" to "twelve"
    )

    init {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) ttsReady = true
        }
    }

    fun announceCarStatus(cars: Set<String>, onDone: () -> Unit = {}) {
        val todayIsOdd = isTodayOdd()
        val dayWord = if (todayIsOdd) "မနေ့" else "စုံနေ့"

        val canGoList = mutableListOf<String>()
        val cannotGoList = mutableListOf<String>()

        for (car in cars) {
            val isOdd = extractStartDigit(car) % 2 != 0
            val canGo = (isOdd && todayIsOdd) || (!isOdd && !todayIsOdd)
            if (canGo) canGoList.add(car) else cannotGoList.add(car)
        }

        queue.clear()

        // Opening in Myanmar
        queue.add(Pair("ယနေ့သည် ${dayWord} ဖြစ်သည်", "my"))

        for (car in cannotGoList) {
            val num = speakableCarNumber(car.substringBefore("/"))
            queue.add(Pair(num, "en"))                                    // car number in English
            queue.add(Pair("ကားကို အသုံးမပြုနိုင်ပါ", "my"))            // result in Myanmar
        }
        for (car in canGoList) {
            val num = speakableCarNumber(car.substringBefore("/"))
            queue.add(Pair(num, "en"))                                    // car number in English
            queue.add(Pair("ကားကို အသုံးပြုနိုင်ပါသည်", "my"))          // result in Myanmar
        }

        // Pre-fetch all audio before playing — eliminates network gaps
        prefetchAndPlay(onDone)
    }

    private fun prefetchAndPlay(onDone: () -> Unit) {
        if (queue.isEmpty()) { onDone(); return }

        val players = Array<MediaPlayer?>(queue.size) { null }
        var fetched = 0

        for (i in queue.indices) {
            val (text, lang) = queue[i]
            val url = buildUrl(text, lang)
            val mp = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build()
                )
                try {
                    setDataSource(url)
                    setOnPreparedListener {
                        fetched++
                        players[i] = this
                        if (fetched == queue.size) {
                            // All fetched — play in sequence with NO delay
                            handler.post { playSequence(players, 0, onDone) }
                        }
                    }
                    setOnErrorListener { _, _, _ ->
                        fetched++
                        players[i] = null
                        if (fetched == queue.size) {
                            handler.post { playSequence(players, 0, onDone) }
                        }
                        true
                    }
                    prepareAsync()
                } catch (e: Exception) {
                    fetched++
                    players[i] = null
                    if (fetched == queue.size) {
                        handler.post { playSequence(players, 0, onDone) }
                    }
                }
            }
        }
    }

    private fun playSequence(players: Array<MediaPlayer?>, index: Int, onDone: () -> Unit) {
        if (index >= players.size) {
            onDone()
            return
        }
        val mp = players[index]
        if (mp == null) {
            // Skip failed, play next immediately
            playSequence(players, index + 1, onDone)
            return
        }
        mp.setOnCompletionListener {
            mp.release()
            // No delay — immediately play next
            playSequence(players, index + 1, onDone)
        }
        mp.start()
    }

    private fun buildUrl(text: String, lang: String): String {
        val encoded = URLEncoder.encode(text, "UTF-8")
        return "https://translate.google.com/translate_tts?ie=UTF-8&q=$encoded&tl=$lang&client=tw-ob"
    }

    private fun speakableCarNumber(prefix: String): String {
        val digits = prefix.filter { it.isDigit() }
        val letters = prefix.filter { it.isLetter() }
        val numberWord = numberWords[digits] ?: digits
        val letterSpelled = letters.map { it.toString() }.joinToString(" ")
        return "$numberWord $letterSpelled"
    }

    fun stop() {
        mediaPlayer?.stop()
        mediaPlayer?.release()
        mediaPlayer = null
        nextPlayer?.stop()
        nextPlayer?.release()
        nextPlayer = null
        tts?.stop()
        queue.clear()
        handler.removeCallbacksAndMessages(null)
    }

    fun shutdown() { stop(); tts?.shutdown() }

    private fun extractStartDigit(carNumber: String) =
        Regex("^(\\d+)").find(carNumber)?.value?.toIntOrNull() ?: 0

    private fun isTodayOdd() =
        Calendar.getInstance().get(Calendar.DAY_OF_MONTH) % 2 != 0
}
