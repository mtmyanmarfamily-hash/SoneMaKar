package com.myanmar.sonemakar

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.util.Log
import java.net.URLEncoder
import java.util.Calendar
import java.util.Locale

class VoiceAnnouncementService(private val context: Context) {

    private var mediaPlayer: MediaPlayer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val handler = Handler(Looper.getMainLooper())

    // Pre-built sentence parts for Myanmar
    // We use Google Translate TTS API as fallback for Myanmar
    private val sentences = mutableListOf<String>()

    init {
        // Initialize TTS as backup
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val myanmar = Locale("my", "MM")
                val result = tts?.setLanguage(myanmar)
                ttsReady = result != TextToSpeech.LANG_MISSING_DATA &&
                           result != TextToSpeech.LANG_NOT_SUPPORTED
                if (!ttsReady) {
                    // Try English fallback
                    tts?.setLanguage(Locale.ENGLISH)
                    ttsReady = true
                }
                tts?.setSpeechRate(0.85f)
            }
        }
    }

    fun announceCarStatus(cars: Set<String>, onDone: () -> Unit = {}) {
        val todayIsOdd = isTodayOdd()
        val dayWord = if (todayIsOdd) "မနေ့" else "စုံနေ့"

        val canGoList = mutableListOf<String>()
        val cannotGoList = mutableListOf<String>()

        for (car in cars) {
            val startDigit = extractStartDigit(car)
            val isOdd = startDigit % 2 != 0
            val canGo = (isOdd && todayIsOdd) || (!isOdd && !todayIsOdd)
            if (canGo) canGoList.add(car) else cannotGoList.add(car)
        }

        // Build speech sentences list
        sentences.clear()
        sentences.add("ယနေ့သည် ${dayWord} ဖြစ်သည်")

        for (car in cannotGoList) {
            val prefix = car.substringBefore("/")
            sentences.add("${prefix} ကားကို အသုံးမပြုနိုင်ပါ")
        }
        for (car in canGoList) {
            val prefix = car.substringBefore("/")
            sentences.add("${prefix} ကားကို အသုံးပြုနိုင်ပါသည်")
        }

        // Play sentences one by one using Google TTS online
        playSentenceSequence(0, onDone)
    }

    private fun playSentenceSequence(index: Int, onDone: () -> Unit) {
        if (index >= sentences.size) {
            onDone()
            return
        }

        val text = sentences[index]
        playGoogleTTS(text, "my") {
            // After each sentence, play next with small delay
            handler.postDelayed({
                playSentenceSequence(index + 1, onDone)
            }, 300)
        }
    }

    private fun playGoogleTTS(text: String, lang: String, onComplete: () -> Unit) {
        try {
            val encoded = URLEncoder.encode(text, "UTF-8")
            // Google Translate TTS - works for Myanmar language
            val url = "https://translate.google.com/translate_tts?ie=UTF-8&q=$encoded&tl=$lang&client=tw-ob"

            mediaPlayer?.release()
            mediaPlayer = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build()
                )
                setDataSource(url)
                setOnPreparedListener { start() }
                setOnCompletionListener { onComplete() }
                setOnErrorListener { _, _, _ ->
                    // Fallback to Android TTS if network fails
                    fallbackTTS(text, onComplete)
                    true
                }
                prepareAsync()
            }
        } catch (e: Exception) {
            fallbackTTS(text, onComplete)
        }
    }

    private fun fallbackTTS(text: String, onComplete: () -> Unit) {
        if (ttsReady) {
            val id = "utt_${System.currentTimeMillis()}"
            tts?.speak(text, TextToSpeech.QUEUE_ADD, null, id)
            // Estimate duration and call onComplete after
            handler.postDelayed({ onComplete() }, (text.length * 120L).coerceAtLeast(1500L))
        } else {
            onComplete()
        }
    }

    fun stop() {
        mediaPlayer?.stop()
        mediaPlayer?.release()
        mediaPlayer = null
        tts?.stop()
        handler.removeCallbacksAndMessages(null)
    }

    fun shutdown() {
        stop()
        tts?.shutdown()
    }

    private fun extractStartDigit(carNumber: String): Int {
        val match = Regex("^(\\d+)").find(carNumber)
        return match?.value?.toIntOrNull() ?: 0
    }

    private fun isTodayOdd(): Boolean {
        val day = Calendar.getInstance().get(Calendar.DAY_OF_MONTH)
        return day % 2 != 0
    }
}
