package com.myanmar.sonemakar

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

class VoiceAnnouncementService(private val context: Context) {

    private var tts: TextToSpeech? = null
    private var isReady = false

    init {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                // Try Myanmar locale first, fallback to English
                val myanmarLocale = Locale("my", "MM")
                val result = tts?.setLanguage(myanmarLocale)
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    // Fallback to English for reading Myanmar romanized
                    tts?.setLanguage(Locale.ENGLISH)
                }
                tts?.setSpeechRate(0.85f)
                tts?.setPitch(1.0f)
                isReady = true
            }
        }
    }

    fun announceCarStatus(cars: Set<String>) {
        if (!isReady) return

        val todayIsOdd = isTodayOdd()
        val dayWord = if (todayIsOdd) "မနေ့" else "စုံနေ့"

        val canGoList = mutableListOf<String>()
        val cannotGoList = mutableListOf<String>()

        for (car in cars) {
            val startDigit = extractStartDigit(car)
            val isOdd = startDigit % 2 != 0
            val canGo = (isOdd && todayIsOdd) || (!isOdd && !todayIsOdd)
            if (canGo) canGoList.add(car) else cannotGoList.add(car)
        }

        val speechText = buildSpeechText(dayWord, todayIsOdd, canGoList, cannotGoList)
        speak(speechText)
    }

    private fun buildSpeechText(
        dayWord: String,
        todayIsOdd: Boolean,
        canGoList: List<String>,
        cannotGoList: List<String>
    ): String {
        val sb = StringBuilder()

        sb.append("ယနေ့သည် ${dayWord} ဖြစ်သည်။ ")

        if (cannotGoList.isNotEmpty()) {
            if (cannotGoList.size == 1) {
                sb.append("${formatCarNumber(cannotGoList[0])} ကားကို အသုံးမပြုနိုင်ပါ။ ")
            } else {
                val carNames = cannotGoList.joinToString("၊ ") { formatCarNumber(it) }
                sb.append("$carNames ကားများကို အသုံးမပြုနိုင်ပါ။ ")
            }
        }

        if (canGoList.isNotEmpty()) {
            if (canGoList.size == 1) {
                sb.append("${formatCarNumber(canGoList[0])} ကားကို အသုံးပြုနိုင်ပါသည်။")
            } else {
                val carNames = canGoList.joinToString("၊ ") { formatCarNumber(it) }
                sb.append("$carNames ကားများကို အသုံးပြုနိုင်ပါသည်။")
            }
        }

        if (canGoList.isEmpty() && cannotGoList.isNotEmpty()) {
            sb.append("ယနေ့ ကားများ အားလုံး အသုံးမပြုနိုင်ပါ။")
        }

        return sb.toString()
    }

    private fun formatCarNumber(carNumber: String): String {
        // "2F/2138" → "၂ အက်ဖ်" (speak just the prefix part)
        val prefix = carNumber.substringBefore("/")
        return prefix
    }

    private fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "CAR_STATUS_${System.currentTimeMillis()}")
    }

    private fun extractStartDigit(carNumber: String): Int {
        val match = Regex("^(\\d+)").find(carNumber)
        return match?.value?.toIntOrNull() ?: 0
    }

    private fun isTodayOdd(): Boolean {
        val day = java.util.Calendar.getInstance().get(java.util.Calendar.DAY_OF_MONTH)
        return day % 2 != 0
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
    }
}
