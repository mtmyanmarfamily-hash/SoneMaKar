package com.myanmar.sonemakar

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import java.io.File
import java.io.FileOutputStream
import java.net.URL
import java.util.Calendar
import java.util.Locale
import java.net.URLEncoder
import kotlin.concurrent.thread

class VoiceAnnouncementService(private val context: Context) {

    private val handler = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val cacheDir = File(context.cacheDir, "tts_cache")

    private val numberWords = mapOf(
        "0" to "zero", "1" to "one", "2" to "two", "3" to "three",
        "4" to "four", "5" to "five", "6" to "six", "7" to "seven",
        "8" to "eight", "9" to "nine", "10" to "ten", "11" to "eleven",
        "12" to "twelve"
    )

    init {
        cacheDir.mkdirs()
        clearOldCache() // clear yesterday's cache on startup
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) ttsReady = true
        }
    }

    // Cache file named by: text_lang_dayOfMonth.mp3
    // So it auto-invalidates next day
    private fun cacheFile(text: String, lang: String): File {
        val day = Calendar.getInstance().get(Calendar.DAY_OF_MONTH)
        val safeName = text.replace(Regex("[^a-zA-Z0-9ကခဂ-ဪဿ၀-၉]"), "_").take(40)
        return File(cacheDir, "${safeName}_${lang}_day${day}.mp3")
    }

    // Delete cache files from previous days
    private fun clearOldCache() {
        val today = Calendar.getInstance().get(Calendar.DAY_OF_MONTH)
        cacheDir.listFiles()?.forEach { file ->
            if (!file.name.contains("_day${today}.mp3")) {
                file.delete()
            }
        }
    }

    fun announceCarStatus(cars: Set<String>, onDone: () -> Unit = {}) {
        val todayIsOdd = isTodayOdd()
        val dayWord = if (todayIsOdd) "မနေ့" else "စုံနေ့"

        val canGoList = mutableListOf<String>()
        val cannotGoList = mutableListOf<String>()

        for (car in cars) {
            val isOdd = extractStartDigit(car) % 2 != 0
            val canGo = (isOdd && todayIsOdd) || (!isOdd && !todayIsOdd)
            if (canGo) canGoList.add(car) else cannotGoList.add(car)
        }

        // Build queue: Pair(text, lang)
        val queue = mutableListOf<Pair<String, String>>()
        queue.add(Pair("ယနေ့သည် ${dayWord} ဖြစ်သည်", "my"))
        for (car in cannotGoList) {
            queue.add(Pair(speakableCarNumber(car.substringBefore("/")), "en"))
            queue.add(Pair("ကားကို အသုံးမပြုနိုင်ပါ", "my"))
        }
        for (car in canGoList) {
            queue.add(Pair(speakableCarNumber(car.substringBefore("/")), "en"))
            queue.add(Pair("ကားကို အသုံးပြုနိုင်ပါသည်", "my"))
        }

        // Fetch all (from cache or network) then play
        thread {
            val files = queue.map { (text, lang) -> fetchAudio(text, lang) }
            handler.post { playSequence(files, 0, onDone) }
        }
    }

    // Returns cached file if exists, otherwise downloads and caches it
    private fun fetchAudio(text: String, lang: String): File? {
        val file = cacheFile(text, lang)
        if (file.exists() && file.length() > 0) {
            return file // ✅ Cache hit — no network needed
        }
        // Cache miss — download once and save
        return try {
            val encoded = URLEncoder.encode(text, "UTF-8")
            val url = "https://translate.google.com/translate_tts?ie=UTF-8&q=$encoded&tl=$lang&client=tw-ob"
            val bytes = URL(url).readBytes()
            FileOutputStream(file).use { it.write(bytes) }
            file
        } catch (e: Exception) {
            null
        }
    }

    private fun playSequence(files: List<File?>, index: Int, onDone: () -> Unit) {
        if (index >= files.size) { onDone(); return }
        val file = files[index]
        if (file == null || !file.exists()) {
            playSequence(files, index + 1, onDone)
            return
        }
        try {
            MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build()
                )
                setDataSource(file.absolutePath)
                setOnPreparedListener { start() }
                setOnCompletionListener {
                    release()
                    playSequence(files, index + 1, onDone) // next immediately
                }
                setOnErrorListener { _, _, _ ->
                    release()
                    playSequence(files, index + 1, onDone)
                    true
                }
                prepare() // sync since it's local file
                start()
            }
        } catch (e: Exception) {
            playSequence(files, index + 1, onDone)
        }
    }

    private fun speakableCarNumber(prefix: String): String {
        val digits = prefix.filter { it.isDigit() }
        val letters = prefix.filter { it.isLetter() }
        val numberWord = numberWords[digits] ?: digits
        val letterSpelled = letters.map { it.toString() }.joinToString(" ")
        return "$numberWord $letterSpelled"
    }

    fun stop() {
        handler.removeCallbacksAndMessages(null)
        tts?.stop()
    }

    fun shutdown() { stop(); tts?.shutdown() }

    private fun extractStartDigit(carNumber: String) =
        Regex("^(\\d+)").find(carNumber)?.value?.toIntOrNull() ?: 0

    private fun isTodayOdd() =
        Calendar.getInstance().get(Calendar.DAY_OF_MONTH) % 2 != 0
}
