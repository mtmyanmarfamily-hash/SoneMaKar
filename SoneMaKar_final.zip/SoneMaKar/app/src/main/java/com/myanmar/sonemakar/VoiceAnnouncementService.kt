package com.myanmar.sonemakar

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import java.io.File
import java.io.FileOutputStream
import java.net.URL
import java.net.URLEncoder
import java.util.Calendar
import kotlin.concurrent.thread

class VoiceAnnouncementService(private val context: Context) {

    private val handler = Handler(Looper.getMainLooper())
    private val cacheDir = File(context.cacheDir, "tts_cache")
    private var stopped = false

    private val numberWords = mapOf(
        "0" to "zero", "1" to "one", "2" to "two", "3" to "three",
        "4" to "four", "5" to "five", "6" to "six", "7" to "seven",
        "8" to "eight", "9" to "nine", "10" to "ten", "11" to "eleven",
        "12" to "twelve"
    )

    init {
        cacheDir.mkdirs()
        clearOldCache()
    }

    private fun cacheFile(text: String, lang: String): File {
        val day = Calendar.getInstance().get(Calendar.DAY_OF_MONTH)
        val safeName = text.replace(Regex("[^a-zA-Z0-9]"), "_").take(30)
        return File(cacheDir, "${safeName}_${lang}_d${day}.mp3")
    }

    private fun clearOldCache() {
        val today = Calendar.getInstance().get(Calendar.DAY_OF_MONTH)
        cacheDir.listFiles()?.forEach { file ->
            if (!file.name.endsWith("_d${today}.mp3")) file.delete()
        }
    }

    fun announceCarStatus(cars: Set<String>, onDone: () -> Unit = {}) {
        stopped = false
        val todayIsOdd = isTodayOdd()
        val dayWord = if (todayIsOdd) "မနေ့" else "စုံနေ့"

        val canGoList = mutableListOf<String>()
        val cannotGoList = mutableListOf<String>()

        for (car in cars) {
            val isOdd = extractStartDigit(car) % 2 != 0
            val canGo = (isOdd && todayIsOdd) || (!isOdd && !todayIsOdd)
            if (canGo) canGoList.add(car) else cannotGoList.add(car)
        }

        val queue = mutableListOf<Pair<String, String>>()
        queue.add(Pair("ယနေ့သည် ${dayWord} ဖြစ်သည်", "my"))
        for (car in cannotGoList) {
            queue.add(Pair(speakableCarNumber(car.substringBefore("/")), "en"))
            queue.add(Pair("ကားကို အသုံးမပြုနိုင်ပါ", "my"))
        }
        for (car in canGoList) {
            queue.add(Pair(speakableCarNumber(car.substringBefore("/")), "en"))
            queue.add(Pair("ကားကို အသုံးပြုနိုင်ပါသည်", "my"))
        }

        // Download all in background, then play on main thread
        thread {
            val files = queue.map { (text, lang) -> fetchAudio(text, lang) }
            handler.post { playNext(files, 0, onDone) }
        }
    }

    private fun fetchAudio(text: String, lang: String): File? {
        val file = cacheFile(text, lang)
        if (file.exists() && file.length() > 1000) return file // cache hit
        return try {
            val encoded = URLEncoder.encode(text, "UTF-8")
            val url = "https://translate.google.com/translate_tts?ie=UTF-8&q=$encoded&tl=$lang&client=tw-ob"
            val bytes = URL(url).readBytes()
            if (bytes.size > 1000) {
                FileOutputStream(file).use { it.write(bytes) }
                file
            } else null
        } catch (e: Exception) {
            null
        }
    }

    private fun playNext(files: List<File?>, index: Int, onDone: () -> Unit) {
        if (stopped || index >= files.size) {
            onDone()
            return
        }
        val file = files[index]
        if (file == null || !file.exists()) {
            playNext(files, index + 1, onDone)
            return
        }
        try {
            val mp = MediaPlayer()
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .build()
            )
            mp.setDataSource(file.absolutePath)
            mp.setOnCompletionListener {
                mp.release()
                playNext(files, index + 1, onDone)
            }
            mp.setOnErrorListener { _, _, _ ->
                mp.release()
                playNext(files, index + 1, onDone)
                true
            }
            mp.prepare()  // sync OK — file is local
            mp.start()
        } catch (e: Exception) {
            playNext(files, index + 1, onDone)
        }
    }

    private fun speakableCarNumber(prefix: String): String {
        val digits = prefix.filter { it.isDigit() }
        val letters = prefix.filter { it.isLetter() }
        val numberWord = numberWords[digits] ?: digits
        val letterSpelled = letters.map { it.toString() }.joinToString(" ")
        return "$numberWord $letterSpelled"
    }

    fun stop() {
        stopped = true
        handler.removeCallbacksAndMessages(null)
    }

    fun shutdown() { stop() }

    private fun extractStartDigit(carNumber: String) =
        Regex("^(\\d+)").find(carNumber)?.value?.toIntOrNull() ?: 0

    private fun isTodayOdd() =
        Calendar.getInstance().get(Calendar.DAY_OF_MONTH) % 2 != 0
}
