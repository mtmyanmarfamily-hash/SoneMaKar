package com.myanmar.sonemakar

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class NotificationReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val prefs = context.getSharedPreferences("SoneMaKarPrefs", Context.MODE_PRIVATE)
        val cars = prefs.getStringSet("car_numbers", emptySet()) ?: emptySet()
        if (cars.isNotEmpty()) {
            NotificationHelper.sendDailyNotification(context, cars)
        }
    }
}
